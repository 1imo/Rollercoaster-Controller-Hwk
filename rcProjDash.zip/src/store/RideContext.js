import React from "react";
import { createContext, useState, useReducer } from "react";
import { initializeApp } from "firebase/app";
import { getDatabase, ref, get, set, child, remove, onValue, onChildChanged } from "firebase/database"


const firebaseConfig = {
    apiKey: "AIzaSyDtzcahy4rUS4ExSv5y0GzjcrA4apX0-bY",
    authDomain: "rcproj-ced8b.firebaseapp.com",
    databaseURL: "https://rcproj-ced8b-default-rtdb.firebaseio.com",
    projectId: "rcproj-ced8b",
    storageBucket: "rcproj-ced8b.appspot.com",
    messagingSenderId: "168977297229",
    appId: "1:168977297229:web:335f427b5c2665525fd104"
  };
  
  
const app = initializeApp(firebaseConfig);


const db = getDatabase()
const dbref = ref(db)


const RideContext = createContext()


export function RideContextHandler(props) {
    // Wanted pm every one of these variables to be a state, however, the setter kept making everything freeze
    // Do you have any feedback on this problem?
    let rideState = "POWERED OFF"
    const [time, setTime] = useState("00:00")
    
    let frontQueueCount = 0
    let backQueueCount = 0
    
    let frontQueueSeenCount = 0
    let backQueueSeenCount = 0

    let frontSitters = 0
    let backSitters = 0
    


    function timeManager() {
        let timeNow = new Date()
        let hour = timeNow.getHours()
        let min = timeNow.getMinutes()
    
        min = min < 10 ? "0" + min : min
        hour = hour < 10 ? "0" + hour : hour
       
      
        if (time != hour + ":" + min) {
          setTime(hour + ":" + min)
    
          setTimeout(() => {
            timeManager()
          }, 1000);
        }
      }
    
    timeManager() 
    
    const updateRideState = (newStatus, currentTime) => {
        get(child(dbref, "/coasterData/")).then((snapshot) => {
            if (snapshot.exists()) {
                set(child(dbref, "coasterData"), {
                    data: [...snapshot.val().data, [newStatus, currentTime]]
                })
            } else {
                set(child(dbref, "coasterData"), {
                    data: [[newStatus, currentTime]]
                })
            }
        })
    } 

    

    const rideStateSetter = (update) => {
        
       

            if (update == "POWERING OFF" && rideState == "DOCKED") {
                console.log("GOT IT")
                rideState = update
                document.querySelector(".rideState").textContent = rideState
                updateRideState(update, time)
            }


            if (update == "POWERING ON" && rideState == "POWERED OFF") {
                rideState = update
                document.querySelector(".rideState").textContent = rideState

                get(child(dbref, "coasterData")).then((snapshot) => {
                    
                    if (!snapshot.val().data) {
                       
                        set(child(dbref, "coasterData"), {
                            data: [[update, time]]
                        })
                    } else {
                        
                        
                        set(child(dbref, "coasterData"), {
                            data: [...snapshot.val().data, [update, time]]
                        })
                    }
                    
                }).then(() => {
                    
                   
                    get(child(dbref, "currentLine")).then((snapshotTwo) => {
                        if (!snapshotTwo.exists()) {
                            set(child(dbref, "currentLine"), {
                                lineData: [0, 0]
                            })
                        } else {
                            frontQueueSeenCount = snapshotTwo.val().lineData[0]
                            backQueueSeenCount = snapshotTwo.val().lineData[1]
                            // console.log(snapshotTwo.val())
                        }
                    })
                        
                        
                    
                })
            }

            if (update == "POWERED ON" && rideState == "POWERING ON") {
                rideState = update
                document.querySelector(".rideState").textContent = rideState
                updateRideState(update, time)
            }

            if (update == "DOCKED" && rideState == "POWERED ON") {
                rideState = update
                document.querySelector(".rideState").textContent = rideState
                updateRideState(update, time)
            }

        if (update == "IN SESSION" && rideState == "DOCKED") {
                
            

                get(child(dbref, "queue")).then((snapshot) => {
                    
                    
                    if (snapshot.exists()) {
                        
                        frontQueueCount = snapshot.val().front.count
                        backQueueCount = snapshot.val().back.count
                        get(child(dbref, "currentLine")).then((snapshotTwo) => {
                            if (snapshotTwo.exists()) {
                                console.log(frontQueueCount, backQueueCount)
                                frontQueueSeenCount = snapshotTwo.val().lineData[0]
                                backQueueSeenCount = snapshotTwo.val().lineData[1]
                                console.log(frontQueueSeenCount)

                                
                                if (frontQueueCount >= 2) {
                                    frontQueueSeenCount = frontQueueSeenCount + 2
                                    frontSitters = 2
                                } else {
                                    if (frontQueueCount != 0) {
                                        frontQueueSeenCount = frontQueueSeenCount + 1
                                        frontSitters = 1                     
                                    } else {
                                        frontSitters = 0
                                    }
                                }


                                console.log("BACK QUEUE, ", backQueueCount)
                                if (frontSitters == 2) {
                                console.log("2222")
                                    if (backQueueCount >= 26) {
                                       

                                        if (backQueueSeenCount + 26 > backQueueCount - backQueueSeenCount) {
                                            backQueueSeenCount = backQueueCount - backQueueSeenCount + backQueueSeenCount
                                        } else {
                                            backQueueSeenCount = backQueueSeenCount + 26
                                            backSitters = 26
                                        }
                                    }

                                    if (backQueueCount < 26 && backQueueCount != 0) {
                                        console.log("SMALLER THAN")
                                        backQueueSeenCount = backQueueCount
                                        backSitters = backQueueCount
                                    }
                            }
                                if (frontSitters == 1) {
                                    if (backQueueCount >= 26) {
                                        backQueueSeenCount = backQueueSeenCount + 1
                                    }
                                    if (backQueueCount < 26 && backQueueCount != 0) {
                                        backQueueSeenCount = backQueueSeenCount + 1
                                }
                                frontSitters = frontSitters + 1
                            }

                            if (frontSitters == 0) {
                                // backQueueSeenCount = backQueueSeenCount + 1
                                if (backQueueCount >= 26) {
                                    backQueueSeenCount = backQueueSeenCount + 2
                                }
                                if (backQueueCount < 26 && backQueueCount != 0) {
                                    backQueueSeenCount = backQueueSeenCount + 2
                            }
                                frontSitters = frontSitters + 2
                            }


                            }

                            return snapshotTwo
                        
                        }).then(() => {
                            console.log(frontQueueSeenCount)
                            set(child(dbref, "currentLine"), {
                                lineData: [frontQueueSeenCount, backQueueSeenCount]
                            })

                            rideState = update
                            console.log("REGISTER")
                            document.querySelector(".rideState").textContent = rideState
                            updateRideState(update, time)
                            frontSitters = 0
                            backSitters = 0

                            
                        })
                    }
                })
                
            }

            if (update == "DOCKED" && rideState == "IN SESSION") {
                rideState = update
                document.querySelector(".rideState").textContent = rideState
                let currentTime = time
                let minutes = currentTime[3] + currentTime[4]
                if (parseInt(minutes) < 58) {
                    minutes = parseInt(minutes) + 2
                    minutes = minutes < 10 ? "0" + minutes : minutes
                    let futureTime = currentTime[0] + currentTime[1] + currentTime[2] + String(minutes)
                    updateRideState(update, futureTime)
                } else {
                    let hour = parseInt(currentTime[0] + currentTime[1])
                    if (hour != 23) {
                        minutes = parseInt(minutes) + 2 - 60
                        hour += 1
                        minutes = minutes < 10 ? "0" + minutes : minutes
                        hour = hour < 10 ? "0" + hour : hour
                        updateRideState(update, hour+":"+minutes)
                    } else {
                        minutes = parseInt(minutes) + 2 - 60
                        hour = 0
                        minutes = minutes < 10 ? "0" + minutes : minutes
                        hour = hour < 10 ? "0" + hour : hour
                        updateRideState(update, hour+":"+minutes)
                    }
                }
                
            }


            if (update == "POWERED OFF" && rideState == "POWERING OFF") {
                rideState = update
                document.querySelector(".rideState").textContent = rideState
                updateRideState(update, time)
            }

           
        
    }

    const Context = {
        state: rideState,
        stateSetter: rideStateSetter,
        currentTime: time,
        frontQueueSeen: frontQueueSeenCount,
        backQueueSeen: backQueueSeenCount,
    }
    

    


    return <RideContext.Provider value={Context}>
        {props.children}
        </ RideContext.Provider>
}

export default RideContext
