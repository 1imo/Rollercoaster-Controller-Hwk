import React from "react";

function Details(props) {
    return <div>Details</div>
}

export default Details