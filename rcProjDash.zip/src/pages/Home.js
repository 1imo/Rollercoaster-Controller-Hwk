import React, { useState, useEffect, useContext } from "react";
import classes from '../App.module.css';
import { initializeApp } from "firebase/app";
import { getDatabase, ref, get, set, child, remove, onValue, onChildChanged } from "firebase/database"
import TopLevelCard from '../components/TopLevelCard';
import DataCard from "../components/DataCard";
import RideContext from "../store/RideContext";
import ActionsComponent from "../components/ActionsComponent";
import StateCard from "../components/StateCard";
import LargeRideStateCard from "../components/LargeRideStateCard";

const firebaseConfig = {
    apiKey: "AIzaSyDtzcahy4rUS4ExSv5y0GzjcrA4apX0-bY",
    authDomain: "rcproj-ced8b.firebaseapp.com",
    databaseURL: "https://rcproj-ced8b-default-rtdb.firebaseio.com",
    projectId: "rcproj-ced8b",
    storageBucket: "rcproj-ced8b.appspot.com",
    messagingSenderId: "168977297229",
    appId: "1:168977297229:web:335f427b5c2665525fd104"
  };
  
  
const app = initializeApp(firebaseConfig);


const db = getDatabase()
const dbref = ref(db)

const frontDbRef = ref(db, "queue/front")
const backDbRef = ref(db, "queue/back")
const lineDbRef = ref(db, "currentLine")

  
  
function Home() {

  const RideCtx = useContext(RideContext)
  
  
  

    const [normLineCount, setNormLineCount] = useState(0)
    const [frontLineCount, setFrontLineCount] = useState(0)
    const [normLineSeenCount, setNormLineSeenCount] = useState(0)
    const [frontLineSeenCount, setFrontLineSeenCount] = useState(0)
    const [time, setTime] = useState("00:00")
    const [latestLineEntryData, setLatestLineEntryData] = useState([])
    const [lineEntryData, setLineEntryData] = useState([])
    const [lineDataCard, setLineDataCard] = useState(<div>Loading</div>)
  
    function timeManager() {
      let timeNow = new Date()
      let hour = timeNow.getHours()
      let min = timeNow.getMinutes()
  
      min = min < 10 ? "0" + min : min
      hour = hour < 10 ? "0" + hour : hour
     
    
      if (time != hour + ":" + min) {
        setTime(hour + ":" + min)
  
        setTimeout(() => {
          timeManager()
        }, 1000);
      }
    }
  
  timeManager() 
  
  

 
  
  useEffect(() => {
    get(child(dbref, "queue/front")).then((data) => {
      if (data.exists()) {
        setFrontLineCount(data.val().count)
        // return data
      }
    }).then(() => {
      get(child(dbref, "currentLine/lineData")).then((dataTwo) => {
        if (dataTwo.exists()) {
          
          if (frontLineCount - frontLineSeenCount >= 0) {
            setFrontLineSeenCount(dataTwo.val()[0])
            // setFrontLineCount(frontLineCount - frontLineSeenCount)
            
          }
        }
      })
    })
    
  
    get(child(dbref, "queue/back")).then((data) => {
      if (data.exists()) {
        setNormLineCount(data.val().count)
        // console.log(data.val().count)
        // setFrontLineCount(data.val().count)

        // return data
      }
    }).then(() => {
      // console.log("THEN")
      get(child(dbref, "currentLine/lineData")).then((dataTwo) => {
        if (dataTwo.exists()) {
          
          if (normLineCount - normLineSeenCount >= 0) {
            setNormLineSeenCount(dataTwo.val()[1])
            // setNormLineCount(normLineCount - normLineSeenCount)
            
          }
        }
      })
    })
  }, [])

  
  



  onChildChanged(frontDbRef, (snapshot) => {
    let data = snapshot.val()
    setFrontLineCount(data)
  })
    
  
  onChildChanged(lineDbRef, (snapshot) => {
    console.log("CHANG")
    // console.log(snapshot.val())
    // setNormLineSeenCount(snapshot.val()[1])
    console.log(frontLineCount)
    console.log(frontLineSeenCount)
    console.log(snapshot.val()[0])

    if (frontLineCount- snapshot.val()[0] >= 0) {
      console.log("CHANG2")
      // setFrontLineCount(frontLineCount + frontLineSeenCount)
      setFrontLineSeenCount(snapshot.val()[0])
      // setFrontLineCount(frontLineCount - frontLineSeenCount)
      
    }

    
    if (normLineCount - snapshot.val()[1] >= 0) {
      // setNormLineCount(normLineCount + normLineSeenCount)
      setNormLineSeenCount(snapshot.val()[1])
      // setNormLineCount(normLineCount - normLineSeenCount)
      
    }
    
  })


  onChildChanged(backDbRef, (snapshot) => {
    let data = snapshot.val()
    setNormLineCount(data)
  })
    
    


  
 
// console.log(RideContext.frontSeenCount)

  
    
  
    return (
      <div className="hi">
        <div className={classes.topLevelCardContainer}>
          <TopLevelCard innerText={frontLineCount - frontLineSeenCount} />
          <TopLevelCard innerText={normLineCount - normLineSeenCount} />
          <StateCard innerText={RideCtx.state} />
          <TopLevelCard innerText={time} />
            </div>
          
        <div className={classes.largeCardContainer}>
          <DataCard cardType="Line Entry Data" database={dbref} />     
          <LargeRideStateCard cardType="Ride Data"/>
        </div>
        
        <ActionsComponent />
  
      </div>
    )
  
    
}

export default Home