import React from "react";
import { useContext } from "react";
import classes from "./ActionsComponent.module.css"

import RideContext from "../store/RideContext";


function ActionsComponent() {

    const RideCtx = useContext(RideContext)

    const powerOn = () => {
        console.log("POWER ON")
        RideCtx.stateSetter("POWERING ON")
        setTimeout(() => {
            RideCtx.stateSetter("POWERED ON")
        }, 8000);
        setTimeout(() => {
            RideCtx.stateSetter("DOCKED")
        }, 10000);
    }

    const startRide = () => {
        console.log("START RIDE")
        RideCtx.stateSetter("IN SESSION")
        setTimeout(() => {
            RideCtx.stateSetter("DOCKED")
        }, 12000);
    }

    const powerOff = () => {
        console.log("POWER OFF")
        RideCtx.stateSetter("POWERING OFF")
        setTimeout(() => {
            RideCtx.stateSetter("POWERED OFF")
        }, 5000);
    }


    return <div className={classes.ActionsCompCard}>
        <h1 className={classes.ActionsCompCardHead}>Actions</h1>
        <div className={classes.ActionsCompCardBtnContainer}>
            <button onClick={powerOn} className={classes.ActionCompCardBtnOn}>Power On</button>
            <button onClick={startRide} className={classes.ActionCompCardBtnStart}>Start Ride</button>
            <button onClick={powerOff} className={classes.ActionCompCardBtnOff}>Power Off</button>
        </div>
        
        
    </div>
}

export default ActionsComponent