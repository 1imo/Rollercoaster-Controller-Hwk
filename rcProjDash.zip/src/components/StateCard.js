import React from "react";
import classes from "./StateCard.css"

function StateCard(props) {
    return <div className="rideState">
        {props.innerText}
    </div>
}

export default StateCard