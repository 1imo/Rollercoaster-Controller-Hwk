import React from "react";
import classes from "./TopLevelCard.module.css"

function TopLevelCard(props) {
    return <div className={classes.card}>
        {props.innerText}
    </div>
}

export default TopLevelCard