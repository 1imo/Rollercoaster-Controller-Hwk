import React from "react";
import { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getDatabase, ref, onChildChanged } from "firebase/database"
import classes from "./DataCard.module.css"

const firebaseConfig = {
    apiKey: "AIzaSyDtzcahy4rUS4ExSv5y0GzjcrA4apX0-bY",
    authDomain: "rcproj-ced8b.firebaseapp.com",
    databaseURL: "https://rcproj-ced8b-default-rtdb.firebaseio.com",
    projectId: "rcproj-ced8b",
    storageBucket: "rcproj-ced8b.appspot.com",
    messagingSenderId: "168977297229",
    appId: "1:168977297229:web:335f427b5c2665525fd104"
  };
  
  
const app = initializeApp(firebaseConfig);

const db = getDatabase()
const dbref = ref(db)

const dbreference = ref(db, '/');

function DataCard(props) {

    const [lineData, setLineData] = useState([])
    const [reversedLineData, setReversedLineData] = useState([])

    

    useEffect(() => {
        fetch("https://rcproj-ced8b-default-rtdb.firebaseio.com/data.json"
        )
            .then(response => {
                return response.json()
            })
            .then(data => {
                let dataArr = []
                for (const key in data) {
                    const dataForArray = {
                        id: key,
                        ...data[key]
                    }
              
                    dataArr.push(dataForArray)
                }
                
                setLineData(dataArr)
               

                
                
            })
    }, [])

   // Code returns 2 of the same entry
    let sellotape = 0

    onChildChanged(dbreference, (snapshot) => {
        if(snapshot.val().data) {
            if (snapshot.val().data.data) {
    
                if (!lineData.includes(snapshot.val().data.data)) {
                    if (sellotape == 1) {
                        setLineData([...lineData, snapshot.val().data.data])
                        let tempArr = lineData
                        console.log(tempArr)
                        sellotape = 0
                    } else {
                        sellotape+=1
                    }
                    
                }
            }
        }
        

        
        
      });

   
    return <div className={classes.dataCard}>
        <div className={classes.dataCardHeader}>
            <h1 className={classes.dataCardHeaderText}>{props.cardType}</h1>
            <button className={classes.dataCardHeaderBtn}>See More</button>
        </div>

        <ul>
            {
            
            lineData.map((item, index) => {
                if (index >= lineData.length - 6) {
                    return <li key={index}>
                        <div className={classes.dataCardListSubject}>
                            {`Entrant ${item[0]}`}
                        </div>
                        <div className={classes.dataCardListData}>
                            <div>{item[1]}</div>
                            <div>{item[2]}</div>
                            <img src="more-vertical.svg" alt="More Info" />
                        </div>
                    </li>
                }
            })}



        </ul>
    </div>
}

export default DataCard