import React from "react";
import { useState, useEffect, useContext } from "react";
import classes from "./DataCard.module.css"
import { initializeApp } from "firebase/app";
import { getDatabase, ref, onChildChanged, get, child } from "firebase/database"
import RideContext from "../store/RideContext";
const firebaseConfig = {
    apiKey: "AIzaSyDtzcahy4rUS4ExSv5y0GzjcrA4apX0-bY",
    authDomain: "rcproj-ced8b.firebaseapp.com",
    databaseURL: "https://rcproj-ced8b-default-rtdb.firebaseio.com",
    projectId: "rcproj-ced8b",
    storageBucket: "rcproj-ced8b.appspot.com",
    messagingSenderId: "168977297229",
    appId: "1:168977297229:web:335f427b5c2665525fd104"
  };
  
  
const app = initializeApp(firebaseConfig);

const db = getDatabase()
const dbref = ref(db)

const dbreference = ref(db, '/');

function LargeRideStateCard(props) {

    const [stateData, setStateData] = useState([])

    useEffect(() => {
        fetch("https://rcproj-ced8b-default-rtdb.firebaseio.com/coasterData/data.json"
        )
            .then(response => {
                return response.json()
            })
            .then(data => {
                let dataArr = []
                for (const key in data) {
                    const dataForArray = {
                        id: key,
                        ...data[key]
                    }
              
                    dataArr.push(dataForArray)
                }
                
                
                setStateData(dataArr)

            })
    }, [])

    // let sellotape = 0

    onChildChanged(dbreference, (snapshot) => {
        if(snapshot.val().data) {
    
                if (!stateData.includes(snapshot.val().data)) {
                    setStateData(snapshot.val().data)
                    // if (sellotape == 1) {
                        
                    //     // sellotape = 0
                    // } else {
                    //     // sellotape+=1
                    // }
                    
                }
            
        }
        
    });
    
   


    if (stateData.length > 1) {
        return <div className={classes.dataCard}>
        <div className={classes.dataCardHeader}>
            <h1 className={classes.dataCardHeaderText}>{props.cardType}</h1>
            <button className={classes.dataCardHeaderBtn}>See More</button>
        </div>
    
        <ul>
                {
                    
            
            stateData.map((item, index) => {
                if (index >= stateData.length - 6) {
                    return <li key={index}>
                        <div className={classes.dataCardListSubject}>
                            {item[0]}
                        </div>
                        <div className={classes.dataCardListData}>
                            <div>{item[1]}</div>
                            <img src="more-vertical.svg" alt="More Info" />
                        </div>
                    </li>
                }
            })}
    
    
    
            </ul>
            </div>
    } else {
        return <div className={classes.dataCard}>
        <div className={classes.dataCardHeader}>
            <h1 className={classes.dataCardHeaderText}>{props.cardType}</h1>
            <button className={classes.dataCardHeaderBtn}>See More</button>
        </div>
    
        <ul>
        <li>No Data To Display</li>
            </ul>
            </div>
    }

   
}

export default LargeRideStateCard