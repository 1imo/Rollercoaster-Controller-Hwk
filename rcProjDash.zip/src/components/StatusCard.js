import React from "react";
import classes from "./DataCard.module.css"

function StatusCard() {
    return <div className={classes.dataCard}>
    <div className={classes.dataCardHeader}>
        <h1 className={classes.dataCardHeaderText}>{props.cardType}</h1>
        <button className={classes.dataCardHeaderBtn}>See More</button>
    </div>

    </div>
}

export default StatusCard