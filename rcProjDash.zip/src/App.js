import React, { useState, useEffect } from 'react';
// import logo from './logo.svg';
// import classes from './App.module.css';
// import axios from 'axios';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './pages/Home';
import Details from './pages/Details';
import { RideContextHandler } from './store/RideContext';

function App() {
  return <RideContextHandler>
    <BrowserRouter>
      <Routes>
        <Route path="/details" element={<Details />} />
        <Route path="/" element={<Home />} />
      </Routes>
      </BrowserRouter>
  </RideContextHandler>  
}




export default App;
