import { useEffect, useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Dimensions } from 'react-native';
import io from "socket.io-client"
import { initializeApp } from "firebase/app";
import { getDatabase, ref, get, set, child, remove } from "firebase/database"

const firebaseConfig = {
  apiKey: "AIzaSyDtzcahy4rUS4ExSv5y0GzjcrA4apX0-bY",
  authDomain: "rcproj-ced8b.firebaseapp.com",
  databaseURL: "https://rcproj-ced8b-default-rtdb.firebaseio.com",
  projectId: "rcproj-ced8b",
  storageBucket: "rcproj-ced8b.appspot.com",
  messagingSenderId: "168977297229",
  appId: "1:168977297229:web:335f427b5c2665525fd104"
};


const app = initializeApp(firebaseConfig);
const db = getDatabase()

import DropShadow from "react-native-drop-shadow";





export default function App() {

  const [time, setTime] = useState("00:00")

  function timeManager() {
    let timeNow = new Date()
    let hour = timeNow.getHours()
    let min = timeNow.getMinutes()

    min = min < 10 ? "0" + min : min
    hour = hour < 10 ? "0" + hour : hour
   
  
    if (time != hour + ":" + min) {
      setTime(hour + ":" + min)

      setTimeout(() => {
        timeManager()
      }, 1000);
    }
  }

  timeManager()

  function POSTData(input) {
    fetch("https://rcproj-ced8b-default-rtdb.firebaseio.com/data.json",
                    {
                        method: "POST",
                        body: JSON.stringify(input),
                        headers: {
                            "Content-Type": "application/json"
                        }
                    })
  }

  

  let totals = 0
  function updateQueue(position, count) {

    const dbref = ref(db)


    get(child(dbref, "queue/" + position)).then((snapshot) => {
      if (snapshot.exists()) {
        let newCount = count == 1 ? snapshot.val().count + 1 : snapshot.val().count + 10
        set(ref(db, "queue/"+position), {
          count: newCount
        }).then(() => {
          get(child(dbref, "queue/data")).then((snapshot) => {
            totals = snapshot.val().data[0]
          }).then(() => {
            set(ref(db, "queue/data"), {
              data: [totals+count, position == "front"? "FRONT" : "NORM", time]
            }).then(() => {

              let item = [totals + 1, position == "front" ? "FRONT" : "NORM", time]
              if (count > 1) {
                for (let i = 0; i < count; i++) {
                  POSTData([totals + i + 1, position == "front" ? "FRONT" : "NORM", time])
                }
              } else {
                POSTData(item)
              }
                
              
                })
            })
          })
      } else {
        set(ref(db, "queue/"+position), {
          count: count
        }).then(() => {
          get(child(dbref, "queue/data")).then((snapshot) => {

            if (snapshot.exists()) {
              totals = snapshot.val().data[0]
              set(ref(db, "queue/data"), {
                data: [totals + count, position == "front"? "FRONT" : "NORM", time]
              }).then(() => {
                if (count > 1) {
                  for (let i = 0; i < count; i++) {
                    POSTData([totals + count + i + 1, position == "front" ? "FRONT" : "NORM", time])
                  }
                } else {
                  POSTData([totals + count, position == "front" ? "FRONT" : "NORM", time])
                }
              })
            } else {
              set(ref(db, "queue/data"), {
                data: [count, position == "front"? "FRONT" : "NORM", time]
              }).then(() => {
                if (count > 1) {
                  for (let i = 0; i < count; i++) {
                    POSTData([i + 1, position == "front" ? "FRONT" : "NORM", time])
                  }
                } else {
                  POSTData([count, position == "front" ? "FRONT" : "NORM", time])
                }
              })
            }
              
            
          })
        })        
      }
    }).catch(e => {
      console.log(e)
    })

    
    
}
  

  const pressHandler = (line) => {
    updateQueue(line, 1)
  }

  const longPressHandler = (line) => {
    updateQueue(line, 10)
  }



  return (
    <View style={styles.container}>
      <DropShadow style={styles.dropShadow}>
        <TouchableOpacity style={styles.button} onPress={() => pressHandler("front")} onLongPress={() => longPressHandler("front")}>
          <Text style={styles.buttonText}>Queue for Front</Text>
        </TouchableOpacity>
      </DropShadow>
      <DropShadow style={styles.dropShadow}>
        <TouchableOpacity style={styles.button} onPress={() => pressHandler("back")} onLongPress={() => longPressHandler("back")}>
          <Text style={styles.buttonText}>Queue for Back</Text>
        </TouchableOpacity>
      </DropShadow>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: "space-between",
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  button:{
    height: Dimensions.get('window').height / 2 - 50,
    width: "100%",
    borderColor: "#000",
    borderWidth: 5,
    borderRadius: 10,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  dropShadow: {
    width: "100%",
    shadowColor: "#000",
    shadowOffset: { width: 10, height: 10 },
    shadowOpacity: 1,
    shadowRadius: 0,
  },
  buttonText:{
    fontSize: 40,
    lineHeight: "100%",
    fontWeight: "bold"
  },


});
